if True:
    print(1, 2, 3)

if True:
    print(
        1,
        2,
        3
    )
    print(1,
          2,
          3)
