x <- 10

if (x > 3) {
  x <- 3
} else if (x < 3) {
  x <- -3
} else {
  if (x > 0) {
    x <- 1
  }
  x <- 0
}
