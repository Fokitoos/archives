<?php

if (
) {
}

return (
);

return true
    ;

return fn () => (
);

return fn (
) => (
);

return function (
) {
};

return function () {
};

return match (
) {
};

return match () {
};

return new class
{
    public function up()
    {
    }

    public function down(
    ) {
    }
};

$this->foo()
    ->bar(
    )
    ->baz();

$this->get()
    ->each(function () {
    })
    ->each(
        function (
        ) {
        },
    );

return $this->get()
    ->each(function () {
    })
    ->each(
        function (
        ) {
        },
    );
