/**
 * Function foo
 * @param[out] x output
 * @param[in] x input
 */
void foo(int *x, int y) {
    *x = y;
}
