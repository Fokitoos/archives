create table my_table (
    id bigint,
    date date
);
