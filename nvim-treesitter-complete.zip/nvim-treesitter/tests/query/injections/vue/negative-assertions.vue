<script lang="ts"> const foo: number = "1" </script>
<!--                           ^ @!javascript   -->
<style lang="scss"> .bar { &-baz { &.page{ } } } </style>
<!--                           ^ @!css          -->
